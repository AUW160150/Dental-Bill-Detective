# MedBill GenAI Analyzer

## Overview
AI-powered medical/dental bill analysis application. Users upload a dental or medical bill (PDF or text), and the app uses bem.ai API to extract structured billing data (procedure codes, amounts, tooth numbers), then performs downstream analysis with Claude AI to compare against fair market rates, detect billing errors, and generate negotiation scripts and appeal letters.

## Architecture
- **Frontend**: React + TypeScript + Vite + shadcn/ui + Tailwind CSS
- **Backend**: Express.js + Node.js
- **Database**: PostgreSQL via Drizzle ORM
- **AI Extraction**: bem.ai API (for structured PDF data extraction - CDT codes, amounts, etc.)
- **AI Analysis**: Anthropic Claude (via Replit AI Integrations, for text-based bill analysis fallback)
- **File Upload**: Multer for PDF/text uploads
- **PDF Parsing**: pdfjs-dist for text extraction (fallback)

## bem.ai Integration
- **Function**: `dental-bill-extractor` (ID: f_39gGvohwq4Eg7wQ9cSubX8UBn4C) - Transform function with DentalBill schema
- **Workflow**: `dental-bill-processing` (ID: w_39gGwl3l5xbcdekmj9gPnDrE0ys) - Processes PDF submissions
- **Flow**: PDF → POST /v2/calls (base64 encoded) → Poll /v2/calls/{id} → GET /v1-alpha/events (filter by functionCallID for transformedContent)
- **API Key**: Stored in BEM_AI_API_KEY secret
- **Fallback**: If bem.ai fails or returns no data, falls back to Claude AI text extraction

## Key Files
- `shared/schema.ts` - Data models (billAnalyses table, LineItem, BillingError, AnalysisResult interfaces)
- `server/routes.ts` - API routes including `/api/analyze` (POST), `/api/analyses` (GET), bem.ai integration
- `server/storage.ts` - Database storage layer
- `server/db.ts` - Database connection
- `client/src/pages/home.tsx` - Main UI with upload area, results display
- `client/src/App.tsx` - App router

## API Endpoints
- `POST /api/analyze` - Analyze a bill (accepts multipart form data with file, or JSON with text)
- `GET /api/analyses` - Get recent analyses
- `GET /api/analyses/:id` - Get specific analysis

## Database
- `bill_analyses` table stores analysis results with line items, billing errors, negotiation scripts

## Running
- `npm run dev` starts both frontend (Vite) and backend (Express) on port 5000
- `npm run db:push` syncs database schema
