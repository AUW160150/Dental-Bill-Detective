import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Upload, FileText, AlertTriangle, DollarSign, TrendingDown, Phone, Mail, Shield, ChevronDown, ChevronUp, Loader2, Sparkles, Heart, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { AnalysisResult, LineItem, BillingError } from "@shared/schema";

function SavingsHero({ result }: { result: AnalysisResult }) {
  const savingsColor = result.savingsPercent >= 50 ? "text-red-500 dark:text-red-400" : result.savingsPercent >= 25 ? "text-amber-500 dark:text-amber-400" : "text-emerald-500 dark:text-emerald-400";

  return (
    <div className="relative overflow-visible rounded-md border border-border bg-card p-6 md:p-8">
      <div className="absolute top-0 left-0 right-0 h-1 rounded-t-md bg-gradient-to-r from-primary via-chart-2 to-chart-3" />
      <div className="flex flex-col md:flex-row md:items-center gap-6 md:gap-8">
        <div className="flex-1">
          <p className="text-sm text-muted-foreground mb-1">Analysis Complete</p>
          <h2 className="text-xl md:text-2xl font-semibold mb-2" data-testid="text-headline">
            Your bill is <span className={savingsColor}>{result.savingsPercent}% above</span> fair market rates
          </h2>
          <p className="text-muted-foreground text-sm" data-testid="text-summary">{result.summary}</p>
        </div>
        <div className="flex flex-wrap gap-3">
          <StatCard label="Total Billed" value={`$${result.totalBilled.toLocaleString()}`} icon={<DollarSign className="w-4 h-4" />} variant="default" />
          <StatCard label="Fair Value" value={`$${result.fairValue.toLocaleString()}`} icon={<TrendingDown className="w-4 h-4" />} variant="success" />
          <StatCard label="Potential Savings" value={`$${result.potentialSavings.toLocaleString()}`} icon={<Sparkles className="w-4 h-4" />} variant="highlight" />
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value, icon, variant }: { label: string; value: string; icon: React.ReactNode; variant: "default" | "success" | "highlight" }) {
  const borderClass = variant === "highlight" ? "border-primary/30" : variant === "success" ? "border-emerald-500/30 dark:border-emerald-400/30" : "border-border";
  return (
    <div className={`rounded-md border ${borderClass} bg-background px-4 py-3 min-w-[140px]`}>
      <div className="flex items-center gap-1.5 text-muted-foreground mb-1">
        {icon}
        <span className="text-xs">{label}</span>
      </div>
      <p className="text-lg font-semibold" data-testid={`text-stat-${label.toLowerCase().replace(/\s/g, '-')}`}>{value}</p>
    </div>
  );
}

function LineItemsTable({ items }: { items: LineItem[] }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm" data-testid="table-line-items">
        <thead>
          <tr className="border-b border-border">
            <th className="text-left py-3 px-3 text-muted-foreground font-medium">Code</th>
            <th className="text-left py-3 px-3 text-muted-foreground font-medium">Description</th>
            <th className="text-left py-3 px-3 text-muted-foreground font-medium hidden md:table-cell">Tooth</th>
            <th className="text-right py-3 px-3 text-muted-foreground font-medium">Billed</th>
            <th className="text-right py-3 px-3 text-muted-foreground font-medium">Fair Price</th>
            <th className="text-right py-3 px-3 text-muted-foreground font-medium">Overcharge</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item, i) => {
            const isOvercharged = item.overchargePercent > 20;
            return (
              <tr key={i} className="border-b border-border/50 hover-elevate" data-testid={`row-line-item-${i}`}>
                <td className="py-3 px-3">
                  <Badge variant="secondary" className="font-mono text-xs">{item.code}</Badge>
                </td>
                <td className="py-3 px-3">
                  <span className="font-medium">{item.description}</span>
                  {item.surface && <span className="text-muted-foreground text-xs ml-2">({item.surface})</span>}
                </td>
                <td className="py-3 px-3 hidden md:table-cell text-muted-foreground">
                  {item.tooth || "—"}
                </td>
                <td className="py-3 px-3 text-right font-mono">${item.billedAmount.toLocaleString()}</td>
                <td className="py-3 px-3 text-right font-mono text-emerald-600 dark:text-emerald-400">${item.fairPrice.toLocaleString()}</td>
                <td className="py-3 px-3 text-right">
                  {isOvercharged ? (
                    <span className="text-red-500 dark:text-red-400 font-mono font-medium">
                      +${item.overchargeAmount.toLocaleString()} ({item.overchargePercent}%)
                    </span>
                  ) : (
                    <span className="text-muted-foreground font-mono">Fair</span>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

function ErrorsList({ errors }: { errors: BillingError[] }) {
  if (errors.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <Shield className="w-10 h-10 mx-auto mb-3 opacity-40" />
        <p className="font-medium">No billing errors detected</p>
        <p className="text-sm mt-1">Your bill appears to be free of common billing mistakes</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {errors.map((error, i) => {
        const severityClass = error.severity === "high"
          ? "border-red-500/30 bg-red-500/5 dark:bg-red-500/10"
          : error.severity === "medium"
          ? "border-amber-500/30 bg-amber-500/5 dark:bg-amber-500/10"
          : "border-border bg-muted/30";
        const badgeVariant = error.severity === "high" ? "destructive" : "secondary";
        return (
          <div key={i} className={`rounded-md border ${severityClass} p-4`} data-testid={`card-error-${i}`}>
            <div className="flex items-start gap-3">
              <AlertTriangle className={`w-5 h-5 mt-0.5 flex-shrink-0 ${error.severity === "high" ? "text-red-500" : "text-amber-500"}`} />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap mb-1">
                  <Badge variant={badgeVariant} className="text-xs">{error.type}</Badge>
                  <Badge variant="outline" className="text-xs">{error.severity}</Badge>
                </div>
                <p className="text-sm">{error.message}</p>
                {error.potentialRefund > 0 && (
                  <p className="text-sm text-emerald-600 dark:text-emerald-400 font-medium mt-1">
                    Potential refund: ${error.potentialRefund.toLocaleString()}
                  </p>
                )}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function TextBlock({ title, content, icon }: { title: string; content: string; icon: React.ReactNode }) {
  const [expanded, setExpanded] = useState(false);
  const lines = content.split("\n");
  const preview = lines.slice(0, 8).join("\n");
  const hasMore = lines.length > 8;

  return (
    <div>
      <div className="flex items-center gap-2 mb-3">
        {icon}
        <h3 className="font-semibold">{title}</h3>
      </div>
      <div className="rounded-md border border-border bg-muted/30 p-4">
        <pre className="whitespace-pre-wrap text-sm leading-relaxed font-sans" data-testid={`text-block-${title.toLowerCase().replace(/\s/g, '-')}`}>
          {expanded || !hasMore ? content : preview + "\n..."}
        </pre>
        {hasMore && (
          <Button
            variant="ghost"
            size="sm"
            className="mt-2"
            onClick={() => setExpanded(!expanded)}
            data-testid={`button-expand-${title.toLowerCase().replace(/\s/g, '-')}`}
          >
            {expanded ? <ChevronUp className="w-4 h-4 mr-1" /> : <ChevronDown className="w-4 h-4 mr-1" />}
            {expanded ? "Show less" : "Show more"}
          </Button>
        )}
      </div>
    </div>
  );
}

function UploadArea({ onAnalyze, isLoading }: { onAnalyze: (text: string, file?: File) => void; isLoading: boolean }) {
  const [inputMode, setInputMode] = useState<"upload" | "paste">("upload");
  const [pastedText, setPastedText] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [dragOver, setDragOver] = useState(false);

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file && (file.type === "application/pdf" || file.type === "text/plain" || file.name.endsWith(".txt"))) {
      setSelectedFile(file);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) setSelectedFile(file);
  };

  const handleSubmit = () => {
    if (inputMode === "paste" && pastedText.trim()) {
      onAnalyze(pastedText.trim());
    } else if (inputMode === "upload" && selectedFile) {
      onAnalyze("", selectedFile);
    }
  };

  const canSubmit = inputMode === "paste" ? pastedText.trim().length > 0 : selectedFile !== null;

  return (
    <Card className="p-6">
      <div className="flex items-center gap-2 mb-4">
        <FileText className="w-5 h-5 text-primary" />
        <h2 className="text-lg font-semibold">Upload Your Bill</h2>
      </div>

      <Tabs value={inputMode} onValueChange={(v) => setInputMode(v as "upload" | "paste")} className="mb-4">
        <TabsList className="w-full">
          <TabsTrigger value="upload" className="flex-1" data-testid="tab-upload">
            <Upload className="w-4 h-4 mr-2" />
            Upload File
          </TabsTrigger>
          <TabsTrigger value="paste" className="flex-1" data-testid="tab-paste">
            <FileText className="w-4 h-4 mr-2" />
            Paste Text
          </TabsTrigger>
        </TabsList>

        <TabsContent value="upload" className="mt-4">
          <div
            className={`relative border-2 border-dashed rounded-md p-8 text-center transition-colors ${
              dragOver ? "border-primary bg-primary/5" : selectedFile ? "border-emerald-500 bg-emerald-500/5" : "border-border"
            }`}
            onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleDrop}
            data-testid="dropzone-upload"
          >
            <input
              type="file"
              accept=".pdf,.txt"
              onChange={handleFileSelect}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              data-testid="input-file"
            />
            {selectedFile ? (
              <div className="flex flex-col items-center gap-2">
                <FileText className="w-10 h-10 text-emerald-500" />
                <p className="font-medium">{selectedFile.name}</p>
                <p className="text-sm text-muted-foreground">
                  {(selectedFile.size / 1024).toFixed(1)} KB
                </p>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => { e.stopPropagation(); setSelectedFile(null); }}
                  data-testid="button-remove-file"
                >
                  <X className="w-4 h-4 mr-1" />
                  Remove
                </Button>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-2">
                <Upload className="w-10 h-10 text-muted-foreground" />
                <p className="font-medium">Drop your bill here or click to browse</p>
                <p className="text-sm text-muted-foreground">Supports PDF and text files</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="paste" className="mt-4">
          <Textarea
            placeholder="Paste your itemized medical or dental bill text here...&#10;&#10;Example:&#10;D4910 PERIODONTAL MAINTENANCE - $177.00&#10;D2394 RESIN-BASED COMPOSITE - $314.00"
            value={pastedText}
            onChange={(e) => setPastedText(e.target.value)}
            className="min-h-[200px] text-sm font-mono resize-none"
            data-testid="textarea-bill"
          />
        </TabsContent>
      </Tabs>

      <Button
        className="w-full"
        onClick={handleSubmit}
        disabled={!canSubmit || isLoading}
        data-testid="button-analyze"
      >
        {isLoading ? (
          <>
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            Analyzing your bill...
          </>
        ) : (
          <>
            <Sparkles className="w-4 h-4 mr-2" />
            Analyze Bill
          </>
        )}
      </Button>
    </Card>
  );
}

function AnalysisLoadingState() {
  return (
    <div className="space-y-6">
      <Card className="p-6">
        <div className="flex flex-col items-center gap-4 py-8">
          <div className="relative">
            <Loader2 className="w-12 h-12 text-primary animate-spin" />
            <Sparkles className="w-5 h-5 text-primary absolute -top-1 -right-1" />
          </div>
          <div className="text-center">
            <h3 className="text-lg font-semibold mb-1">AI is analyzing your bill</h3>
            <p className="text-sm text-muted-foreground mb-4">Extracting procedure codes, comparing prices, and detecting errors...</p>
          </div>
          <div className="w-full max-w-sm space-y-3">
            <Step label="Extracting structured data with bem.ai" done />
            <Step label="Comparing against fair market prices" active />
            <Step label="Detecting billing errors" />
            <Step label="Generating negotiation materials" />
          </div>
        </div>
      </Card>
    </div>
  );
}

function Step({ label, done, active }: { label: string; done?: boolean; active?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${
        done ? "bg-emerald-500 text-white" : active ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
      }`}>
        {done ? "✓" : active ? <Loader2 className="w-3 h-3 animate-spin" /> : ""}
      </div>
      <span className={`text-sm ${done ? "text-muted-foreground line-through" : active ? "font-medium" : "text-muted-foreground"}`}>
        {label}
      </span>
    </div>
  );
}

function ResultsView({ result }: { result: AnalysisResult }) {
  return (
    <div className="space-y-6">
      <SavingsHero result={result} />

      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <FileText className="w-5 h-5 text-primary" />
          <h3 className="font-semibold">Line-by-Line Analysis</h3>
          <Badge variant="secondary" className="ml-auto">{result.lineItems.length} items</Badge>
        </div>
        <LineItemsTable items={result.lineItems} />
      </Card>

      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <AlertTriangle className="w-5 h-5 text-amber-500" />
          <h3 className="font-semibold">Billing Errors Detected</h3>
          {result.billingErrors.length > 0 && (
            <Badge variant="destructive" className="ml-auto">{result.billingErrors.length} found</Badge>
          )}
        </div>
        <ErrorsList errors={result.billingErrors} />
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <TextBlock
            title="Negotiation Script"
            content={result.negotiationScript}
            icon={<Phone className="w-5 h-5 text-primary" />}
          />
        </Card>
        <Card className="p-6">
          <TextBlock
            title="Appeal Letter"
            content={result.appealLetter}
            icon={<Mail className="w-5 h-5 text-primary" />}
          />
        </Card>
      </div>
    </div>
  );
}

export default function Home() {
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const { toast } = useToast();

  const analyzeMutation = useMutation({
    mutationFn: async ({ text, file }: { text: string; file?: File }) => {
      if (file) {
        const formData = new FormData();
        formData.append("file", file);
        const res = await fetch("/api/analyze", { method: "POST", body: formData });
        if (!res.ok) {
          const errText = await res.text();
          throw new Error(errText || "Analysis failed");
        }
        return res.json();
      } else {
        const res = await apiRequest("POST", "/api/analyze", { text });
        return res.json();
      }
    },
    onSuccess: (data: AnalysisResult) => {
      setResult(data);
      toast({
        title: "Analysis complete",
        description: `Found potential savings of $${data.potentialSavings.toLocaleString()}`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Analysis failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleAnalyze = (text: string, file?: File) => {
    setResult(null);
    analyzeMutation.mutate({ text, file });
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card/50 sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-md bg-primary flex items-center justify-center">
              <Heart className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-lg font-semibold leading-tight" data-testid="text-app-title">MedBill Analyzer</h1>
              <p className="text-xs text-muted-foreground">AI-Powered Bill Analysis</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-xs">
              <Shield className="w-3 h-3 mr-1" />
              Privacy-First
            </Badge>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-6 md:py-8 space-y-8">
        {!result && !analyzeMutation.isPending && (
          <div className="text-center max-w-2xl mx-auto mb-8">
            <h2 className="text-2xl md:text-3xl font-semibold mb-3" data-testid="text-hero-title">
              Understand your medical bills. <br />
              <span className="text-primary">Save money.</span>
            </h2>
            <p className="text-muted-foreground">
              Upload your dental or medical bill and our AI will analyze it against fair market rates,
              detect billing errors, and generate personalized negotiation materials.
            </p>
          </div>
        )}

        {!result && !analyzeMutation.isPending && (
          <div className="max-w-2xl mx-auto">
            <UploadArea onAnalyze={handleAnalyze} isLoading={analyzeMutation.isPending} />
          </div>
        )}

        {analyzeMutation.isPending && <AnalysisLoadingState />}

        {result && (
          <>
            <ResultsView result={result} />
            <div className="flex justify-center pt-4 pb-8">
              <Button
                variant="outline"
                onClick={() => { setResult(null); }}
                data-testid="button-analyze-another"
              >
                <Upload className="w-4 h-4 mr-2" />
                Analyze Another Bill
              </Button>
            </div>
          </>
        )}

        {!result && !analyzeMutation.isPending && (
          <div className="max-w-4xl mx-auto">
            <Separator className="mb-8" />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <FeatureCard
                icon={<TrendingDown className="w-6 h-6 text-primary" />}
                title="Fair Price Analysis"
                description="Compare your charges against Medicare benchmarks and fair market rates."
              />
              <FeatureCard
                icon={<AlertTriangle className="w-6 h-6 text-amber-500" />}
                title="Error Detection"
                description="AI identifies unbundling, duplicates, and overcharges automatically."
              />
              <FeatureCard
                icon={<Phone className="w-6 h-6 text-emerald-500" />}
                title="Negotiation Tools"
                description="Get personalized phone scripts and formal appeal letters."
              />
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <Card className="p-5">
      <div className="mb-3">{icon}</div>
      <h3 className="font-semibold mb-1">{title}</h3>
      <p className="text-sm text-muted-foreground">{description}</p>
    </Card>
  );
}
