import { sql } from "drizzle-orm";
import { pgTable, text, varchar, serial, integer, timestamp, jsonb, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const billAnalyses = pgTable("bill_analyses", {
  id: serial("id").primaryKey(),
  facilityName: text("facility_name"),
  patientName: text("patient_name"),
  billType: text("bill_type").default("dental"),
  rawText: text("raw_text"),
  totalBilled: numeric("total_billed"),
  fairValue: numeric("fair_value"),
  potentialSavings: numeric("potential_savings"),
  savingsPercent: numeric("savings_percent"),
  lineItems: jsonb("line_items").$type<LineItem[]>().default([]),
  billingErrors: jsonb("billing_errors").$type<BillingError[]>().default([]),
  negotiationScript: text("negotiation_script"),
  appealLetter: text("appeal_letter"),
  summary: text("summary"),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const insertBillAnalysisSchema = createInsertSchema(billAnalyses).omit({
  id: true,
  createdAt: true,
});

export type InsertBillAnalysis = z.infer<typeof insertBillAnalysisSchema>;
export type BillAnalysis = typeof billAnalyses.$inferSelect;

export interface LineItem {
  code: string;
  description: string;
  tooth?: string;
  surface?: string;
  billedAmount: number;
  fairPrice: number;
  insurancePays: number;
  patientPays: number;
  overchargeAmount: number;
  overchargePercent: number;
}

export interface BillingError {
  type: string;
  severity: "high" | "medium" | "low";
  message: string;
  potentialRefund: number;
}

export interface AnalysisResult {
  id?: number;
  facilityName: string;
  patientName: string;
  billType: string;
  totalBilled: number;
  fairValue: number;
  potentialSavings: number;
  savingsPercent: number;
  lineItems: LineItem[];
  billingErrors: BillingError[];
  negotiationScript: string;
  appealLetter: string;
  summary: string;
}
