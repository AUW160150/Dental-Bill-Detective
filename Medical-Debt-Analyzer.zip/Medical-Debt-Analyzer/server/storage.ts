import { db } from "./db";
import { billAnalyses, type InsertBillAnalysis, type BillAnalysis } from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  createAnalysis(analysis: InsertBillAnalysis): Promise<BillAnalysis>;
  getAnalysis(id: number): Promise<BillAnalysis | undefined>;
  getRecentAnalyses(): Promise<BillAnalysis[]>;
}

class DatabaseStorage implements IStorage {
  async createAnalysis(analysis: InsertBillAnalysis): Promise<BillAnalysis> {
    const [result] = await db.insert(billAnalyses).values(analysis).returning();
    return result;
  }

  async getAnalysis(id: number): Promise<BillAnalysis | undefined> {
    const [result] = await db.select().from(billAnalyses).where(eq(billAnalyses.id, id));
    return result;
  }

  async getRecentAnalyses(): Promise<BillAnalysis[]> {
    return db.select().from(billAnalyses).orderBy(desc(billAnalyses.createdAt)).limit(20);
  }
}

export const storage = new DatabaseStorage();
