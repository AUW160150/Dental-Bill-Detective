import type { Express } from "express";
import { createServer, type Server } from "http";
import { createRequire } from "module";
import { storage } from "./storage";
import multer from "multer";
import Anthropic from "@anthropic-ai/sdk";
import type { AnalysisResult } from "@shared/schema";

const require = createRequire(import.meta.url);

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });

const anthropic = new Anthropic({
  apiKey: process.env.AI_INTEGRATIONS_ANTHROPIC_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_ANTHROPIC_BASE_URL,
});

const BEM_API_KEY = process.env.BEM_AI_API_KEY || "";
const BEM_BASE_URL = "https://api.bem.ai";
const BEM_WORKFLOW_NAME = "dental-bill-processing";
const BEM_FUNCTION_NAME = "dental-bill-extractor";

const DENTAL_FAIR_PRICES: Record<string, { description: string; fairPrice: number }> = {
  D0120: { description: "Periodic Oral Evaluation", fairPrice: 65 },
  D0150: { description: "Comprehensive Oral Evaluation", fairPrice: 95 },
  D0210: { description: "Intraoral X-rays Complete Series", fairPrice: 150 },
  D0220: { description: "Intraoral X-ray First Film", fairPrice: 35 },
  D0230: { description: "Intraoral X-ray Each Additional", fairPrice: 30 },
  D0274: { description: "Bitewings Four Films", fairPrice: 70 },
  D0330: { description: "Panoramic X-ray", fairPrice: 130 },
  D1110: { description: "Prophylaxis Adult", fairPrice: 110 },
  D1120: { description: "Prophylaxis Child", fairPrice: 80 },
  D1206: { description: "Topical Fluoride Varnish", fairPrice: 40 },
  D1351: { description: "Sealant Per Tooth", fairPrice: 55 },
  D2140: { description: "Amalgam One Surface", fairPrice: 170 },
  D2150: { description: "Amalgam Two Surfaces", fairPrice: 215 },
  D2160: { description: "Amalgam Three Surfaces", fairPrice: 265 },
  D2330: { description: "Resin Composite One Surface Anterior", fairPrice: 195 },
  D2331: { description: "Resin Composite Two Surfaces Anterior", fairPrice: 250 },
  D2332: { description: "Resin Composite Three Surfaces Anterior", fairPrice: 310 },
  D2391: { description: "Resin Composite One Surface Posterior", fairPrice: 205 },
  D2392: { description: "Resin Composite Two Surfaces Posterior", fairPrice: 270 },
  D2393: { description: "Resin Composite Three Surfaces Posterior", fairPrice: 320 },
  D2394: { description: "Resin Composite Four+ Surfaces Posterior", fairPrice: 380 },
  D2740: { description: "Crown Porcelain/Ceramic", fairPrice: 1100 },
  D2750: { description: "Crown Porcelain Fused to Metal", fairPrice: 1050 },
  D2950: { description: "Core Buildup", fairPrice: 300 },
  D3310: { description: "Root Canal Anterior", fairPrice: 850 },
  D3320: { description: "Root Canal Premolar", fairPrice: 1000 },
  D3330: { description: "Root Canal Molar", fairPrice: 1200 },
  D4341: { description: "Scaling/Root Planing Per Quadrant", fairPrice: 275 },
  D4342: { description: "Scaling/Root Planing 1-3 Teeth", fairPrice: 200 },
  D4910: { description: "Periodontal Maintenance", fairPrice: 165 },
  D5110: { description: "Complete Denture Upper", fairPrice: 1800 },
  D5120: { description: "Complete Denture Lower", fairPrice: 1800 },
  D5213: { description: "Partial Upper Metal Framework", fairPrice: 1600 },
  D5214: { description: "Partial Lower Metal Framework", fairPrice: 1600 },
  D6010: { description: "Endosteal Implant", fairPrice: 2200 },
  D6058: { description: "Implant Abutment", fairPrice: 800 },
  D6065: { description: "Implant Crown Porcelain/Ceramic", fairPrice: 1500 },
  D7140: { description: "Extraction Erupted", fairPrice: 200 },
  D7210: { description: "Surgical Extraction", fairPrice: 350 },
  D7240: { description: "Impacted Tooth Removal", fairPrice: 450 },
  D8080: { description: "Comprehensive Orthodontic Treatment", fairPrice: 5500 },
  D8090: { description: "Comprehensive Ortho Treatment Adolescent", fairPrice: 5500 },
  D8680: { description: "Orthodontic Retention", fairPrice: 500 },
  D9110: { description: "Palliative Treatment", fairPrice: 120 },
  D9230: { description: "Nitrous Oxide", fairPrice: 65 },
  D9310: { description: "Consultation", fairPrice: 100 },
};

async function extractTextFromPdf(buffer: Buffer): Promise<string> {
  try {
    const pdfjsLib = await import("pdfjs-dist/legacy/build/pdf.mjs");
    const uint8 = new Uint8Array(buffer);
    const doc = await pdfjsLib.getDocument({ data: uint8 }).promise;
    let text = "";
    for (let i = 1; i <= doc.numPages; i++) {
      const page = await doc.getPage(i);
      const content = await page.getTextContent();
      const pageText = (content.items as any[]).map((item: any) => item.str).join(" ");
      text += pageText + "\n";
    }
    return text;
  } catch (error) {
    console.error("PDF parsing error:", error);
    throw new Error("Failed to extract text from PDF. Please paste the bill text instead.");
  }
}

async function submitToBemAI(pdfBuffer: Buffer): Promise<any> {
  const b64Content = pdfBuffer.toString("base64");
  const referenceId = `bill-${Date.now()}`;

  const callPayload = {
    calls: [{
      workflowName: BEM_WORKFLOW_NAME,
      callReferenceID: referenceId,
      input: {
        singleFile: {
          inputType: "pdf",
          inputContent: b64Content,
        },
      },
    }],
  };

  const submitRes = await fetch(`${BEM_BASE_URL}/v2/calls`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": BEM_API_KEY,
    },
    body: JSON.stringify(callPayload),
  });

  if (!submitRes.ok) {
    const errText = await submitRes.text();
    console.error("bem.ai submit error:", errText);
    throw new Error("Failed to submit bill to extraction service");
  }

  const submitData = await submitRes.json();
  const callId = submitData.calls?.[0]?.callID;
  if (!callId) {
    throw new Error("No call ID returned from extraction service");
  }

  console.log(`bem.ai call submitted: ${callId} (ref: ${referenceId})`);

  const maxAttempts = 30;
  const pollInterval = 3000;
  let functionCallId: string | null = null;

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    await new Promise((resolve) => setTimeout(resolve, pollInterval));

    const statusRes = await fetch(`${BEM_BASE_URL}/v2/calls/${callId}`, {
      headers: { "x-api-key": BEM_API_KEY },
    });

    if (!statusRes.ok) continue;

    const statusData = await statusRes.json();
    const callStatus = statusData.call?.status;

    if (callStatus === "completed") {
      functionCallId = statusData.call?.functionCalls?.[0]?.functionCallID;
      console.log(`bem.ai call completed: ${callId}, functionCallId: ${functionCallId}`);
      break;
    }

    if (callStatus === "failed" || callStatus === "error") {
      throw new Error("Bill extraction failed. Please try again or paste the text instead.");
    }
  }

  if (!functionCallId) {
    throw new Error("Extraction timed out. Please try pasting the bill text instead.");
  }

  for (let evtAttempt = 0; evtAttempt < 5; evtAttempt++) {
    await new Promise((resolve) => setTimeout(resolve, 2000));

    const eventsRes = await fetch(
      `${BEM_BASE_URL}/v1-alpha/events?limit=50`,
      { headers: { "x-api-key": BEM_API_KEY } },
    );

    if (!eventsRes.ok) {
      console.error("bem.ai events error:", await eventsRes.text());
      continue;
    }

    const eventsData = await eventsRes.json();
    const transformEvent = eventsData.events?.find(
      (e: any) =>
        e.functionCallID === functionCallId &&
        e.eventType === "transform" &&
        e.transformedContent,
    );

    if (transformEvent?.transformedContent) {
      console.log("bem.ai extracted data:", JSON.stringify(transformEvent.transformedContent).substring(0, 200));
      return transformEvent.transformedContent;
    }
  }

  console.log("bem.ai: no matching event found for functionCallID:", functionCallId);
  return null;
}

function buildAnalysisFromBemData(bemData: any): {
  facilityName: string;
  patientName: string;
  billType: string;
  lineItems: any[];
  totalBilled: number;
  totalInsurance: number;
  totalPatient: number;
} {
  const lineItems = (bemData.lineItems || []).map((item: any) => ({
    code: (item.code || "").toUpperCase(),
    description: item.description || "",
    tooth: item.tooth || "",
    surface: item.surface || "",
    billedAmount: Number(item.billedAmount) || 0,
    standardFee: Number(item.standardFee) || 0,
    insurancePays: Number(item.insurancePays) || 0,
    patientPays: Number(item.patientPays) || 0,
  }));

  return {
    facilityName: bemData.facilityName || "Unknown Facility",
    patientName: bemData.patientName || "Patient",
    billType: "dental",
    lineItems,
    totalBilled: Number(bemData.totalBilled) || lineItems.reduce((s: number, i: any) => s + i.billedAmount, 0),
    totalInsurance: Number(bemData.totalInsurance) || 0,
    totalPatient: Number(bemData.totalPatient) || 0,
  };
}

async function analyzeBillWithAI(billText: string): Promise<{ facilityName: string; patientName: string; billType: string; lineItems: any[]; totalBilled: number; totalInsurance: number; totalPatient: number }> {
  const prompt = `You are a medical/dental billing expert. Analyze the following bill text and extract structured information.

BILL TEXT:
${billText}

Please analyze this bill and return a JSON object with the following structure:
{
  "facilityName": "name of the dental/medical practice",
  "patientName": "patient name (first name only for privacy, or 'Patient' if not found)",
  "billType": "dental" or "medical",
  "lineItems": [
    {
      "code": "CDT or CPT code (e.g. D2393)",
      "description": "procedure description",
      "tooth": "tooth number if applicable",
      "surface": "surface codes if applicable",
      "billedAmount": 271.00,
      "insurancePays": 203.25,
      "patientPays": 67.75
    }
  ],
  "totalBilled": total billed amount as number,
  "totalInsurance": total insurance pays as number,
  "totalPatient": total patient pays as number
}

Important:
- Extract EVERY line item from the bill
- Use the adjusted/negotiated fee as the billedAmount (not the standard fee)
- If there are "Standard Fee" and "Adjust" lines, use the fee shown on the main line (which is Standard Fee minus Adjust)
- Return ONLY valid JSON, no markdown formatting or code blocks`;

  const message = await anthropic.messages.create({
    model: "claude-sonnet-4-5",
    max_tokens: 8192,
    messages: [{ role: "user", content: prompt }],
  });

  const responseText = message.content[0].type === "text" ? message.content[0].text : "";

  let extracted;
  try {
    const jsonMatch = responseText.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error("No JSON found in response");
    extracted = JSON.parse(jsonMatch[0]);
  } catch (e) {
    console.error("Failed to parse AI response:", responseText);
    throw new Error("AI extraction failed. Please try again.");
  }

  return {
    facilityName: extracted.facilityName || "Unknown Facility",
    patientName: extracted.patientName || "Patient",
    billType: extracted.billType || "dental",
    lineItems: (extracted.lineItems || []).map((item: any) => ({
      code: (item.code || "").toUpperCase(),
      description: item.description || "",
      tooth: item.tooth || "",
      surface: item.surface || "",
      billedAmount: Number(item.billedAmount) || 0,
      insurancePays: Number(item.insurancePays) || 0,
      patientPays: Number(item.patientPays) || 0,
    })),
    totalBilled: Number(extracted.totalBilled) || 0,
    totalInsurance: Number(extracted.totalInsurance) || 0,
    totalPatient: Number(extracted.totalPatient) || 0,
  };
}

function performDownstreamAnalysis(extracted: {
  facilityName: string;
  patientName: string;
  billType: string;
  lineItems: any[];
  totalBilled: number;
  totalInsurance: number;
  totalPatient: number;
}): AnalysisResult {
  const lineItems = extracted.lineItems.map((item: any) => {
    const code = item.code?.toUpperCase() || "";
    const fairPriceData = DENTAL_FAIR_PRICES[code];
    const billedAmount = Number(item.billedAmount) || 0;
    const fairPrice = fairPriceData?.fairPrice || Math.round(billedAmount * 0.7);
    const overchargeAmount = Math.max(0, billedAmount - fairPrice);
    const overchargePercent = fairPrice > 0 ? Math.round((overchargeAmount / fairPrice) * 100) : 0;

    return {
      code,
      description: item.description || fairPriceData?.description || "Unknown Procedure",
      tooth: item.tooth || "",
      surface: item.surface || "",
      billedAmount,
      fairPrice,
      insurancePays: Number(item.insurancePays) || 0,
      patientPays: Number(item.patientPays) || 0,
      overchargeAmount,
      overchargePercent,
    };
  });

  const totalBilled = extracted.totalBilled || lineItems.reduce((s: number, i: any) => s + i.billedAmount, 0);
  const fairValue = lineItems.reduce((s: number, i: any) => s + i.fairPrice, 0);
  const potentialSavings = Math.max(0, totalBilled - fairValue);
  const savingsPercent = fairValue > 0 ? Math.round((potentialSavings / fairValue) * 100) : 0;

  const billingErrors = detectBillingErrors(lineItems);
  const negotiationScript = generateNegotiationScript(extracted.facilityName, totalBilled, fairValue, potentialSavings, lineItems);
  const appealLetter = generateAppealLetter(extracted.facilityName, extracted.patientName, totalBilled, fairValue, lineItems, billingErrors);

  const summary = `Your ${extracted.billType || "dental"} bill from ${extracted.facilityName || "the provider"} totals $${totalBilled.toLocaleString()}. Fair market value is approximately $${fairValue.toLocaleString()}, meaning you could save up to $${potentialSavings.toLocaleString()} (${savingsPercent}% overcharge).${billingErrors.length > 0 ? ` We also detected ${billingErrors.length} potential billing error(s).` : ""}`;

  return {
    facilityName: extracted.facilityName || "Unknown Facility",
    patientName: extracted.patientName || "Patient",
    billType: extracted.billType || "dental",
    totalBilled,
    fairValue,
    potentialSavings,
    savingsPercent,
    lineItems,
    billingErrors,
    negotiationScript,
    appealLetter,
    summary,
  };
}

function detectBillingErrors(lineItems: any[]): any[] {
  const errors: any[] = [];
  const codeCounts = new Map<string, number>();

  for (const item of lineItems) {
    codeCounts.set(item.code, (codeCounts.get(item.code) || 0) + 1);
  }

  for (const [code, count] of Array.from(codeCounts.entries())) {
    if (count > 4 && !["D2391", "D2392", "D2393", "D2394"].includes(code)) {
      errors.push({
        type: "POSSIBLE DUPLICATE",
        severity: "medium" as const,
        message: `Code ${code} appears ${count} times. Verify each instance is a distinct procedure on a different tooth.`,
        potentialRefund: 0,
      });
    }
  }

  for (const item of lineItems) {
    if (item.overchargePercent > 100) {
      errors.push({
        type: "SIGNIFICANT OVERCHARGE",
        severity: "high" as const,
        message: `${item.code} (${item.description}) is billed at $${item.billedAmount} but the fair market price is $${item.fairPrice} — ${item.overchargePercent}% above fair value.`,
        potentialRefund: item.overchargeAmount,
      });
    }
  }

  const hasOrtho = lineItems.some((i: any) => i.code === "D8080" || i.code === "D8090");
  const hasRetention = lineItems.some((i: any) => i.code === "D8680");
  if (hasOrtho && hasRetention) {
    const retentionItem = lineItems.find((i: any) => i.code === "D8680");
    if (retentionItem && retentionItem.billedAmount > 600) {
      errors.push({
        type: "BUNDLING OPPORTUNITY",
        severity: "medium" as const,
        message: `Orthodontic retention (D8680) at $${retentionItem.billedAmount} may be included in comprehensive ortho treatment. Ask if retention is bundled.`,
        potentialRefund: Math.max(0, retentionItem.billedAmount - 500),
      });
    }
  }

  return errors;
}

function generateNegotiationScript(facility: string, totalBilled: number, fairValue: number, savings: number, lineItems: any[]): string {
  const overchargedItems = lineItems.filter((i: any) => i.overchargePercent > 30);
  const topOvercharges = overchargedItems.sort((a: any, b: any) => b.overchargeAmount - a.overchargeAmount).slice(0, 3);

  let script = `Hello, I'm calling about my recent bill from ${facility || "your office"}.

I've been reviewing my itemized statement, and I'd like to discuss some of the charges. My total bill is $${totalBilled.toLocaleString()}, but based on my research of fair market rates in this area, the typical cost for these procedures would be closer to $${fairValue.toLocaleString()}.

That's a difference of $${savings.toLocaleString()}, which is significant for my family.`;

  if (topOvercharges.length > 0) {
    script += `\n\nSpecifically, I'd like to discuss these charges:`;
    for (const item of topOvercharges) {
      script += `\n- ${item.code} (${item.description}): Billed at $${item.billedAmount}, but the fair market rate is around $${item.fairPrice}`;
    }
  }

  script += `\n\nI understand that pricing can vary, but I'm hoping we can work together to find a fair resolution. Would it be possible to:

1. Review these charges and adjust them closer to fair market rates?
2. Set up a payment plan if needed?
3. Discuss any financial hardship programs your office may offer?

I value the care I received and want to resolve this amicably. Thank you for your time.`;

  return script;
}

function generateAppealLetter(facility: string, patient: string, totalBilled: number, fairValue: number, lineItems: any[], errors: any[]): string {
  const date = new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
  const overchargedItems = lineItems.filter((i: any) => i.overchargePercent > 20);

  let letter = `${date}

To: Billing Department
${facility || "[Healthcare Provider]"}

Re: Request for Bill Review and Adjustment

Dear Billing Department,

I am writing to formally request a review of my recent bill totaling $${totalBilled.toLocaleString()}. After careful analysis, I believe several charges exceed fair market rates for my area, and I respectfully request an adjustment.

Based on published fair market data (including FAIR Health consumer data and Medicare fee schedules), the reasonable cost for the services I received would be approximately $${fairValue.toLocaleString()}.`;

  if (overchargedItems.length > 0) {
    letter += `\n\nThe following charges appear to be above fair market rates:\n`;
    for (const item of overchargedItems) {
      letter += `\n- ${item.code} (${item.description}): Billed $${item.billedAmount}, Fair Market Rate: $${item.fairPrice}`;
    }
  }

  if (errors.length > 0) {
    letter += `\n\nAdditionally, I've identified potential billing concerns:\n`;
    for (const error of errors) {
      letter += `\n- ${error.type}: ${error.message}`;
    }
  }

  letter += `\n\nUnder the No Surprises Act and state consumer protection laws, patients have the right to dispute charges that significantly exceed fair market rates. I am requesting:

1. An itemized review of all charges
2. Adjustment of fees to align with fair market rates
3. Correction of any identified billing errors

I am prepared to pay the fair market value for the services I received. Please respond within 30 days with your determination.

Thank you for your attention to this matter.

Sincerely,
[Your Name]`;

  return letter;
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.post("/api/analyze", upload.single("file"), async (req, res) => {
    try {
      let extracted: {
        facilityName: string;
        patientName: string;
        billType: string;
        lineItems: any[];
        totalBilled: number;
        totalInsurance: number;
        totalPatient: number;
      };

      let rawText = "";
      let usedBemAI = false;

      if (req.file) {
        if (req.file.mimetype === "application/pdf") {
          rawText = await extractTextFromPdf(req.file.buffer);

          if (BEM_API_KEY) {
            try {
              console.log("Sending PDF to bem.ai for structured extraction...");
              const bemData = await submitToBemAI(req.file.buffer);

              if (bemData && bemData.lineItems && bemData.lineItems.length > 0) {
                extracted = buildAnalysisFromBemData(bemData);
                usedBemAI = true;
                console.log(`bem.ai extracted ${extracted.lineItems.length} line items successfully`);
              } else {
                console.log("bem.ai returned no usable data, falling back to Claude AI");
                extracted = await analyzeBillWithAI(rawText);
              }
            } catch (bemError: any) {
              console.error("bem.ai extraction failed, falling back to Claude AI:", bemError.message);
              extracted = await analyzeBillWithAI(rawText);
            }
          } else {
            extracted = await analyzeBillWithAI(rawText);
          }
        } else if (req.file.mimetype === "text/plain" || req.file.originalname?.endsWith(".txt")) {
          rawText = req.file.buffer.toString("utf-8");
          extracted = await analyzeBillWithAI(rawText);
        } else {
          return res.status(400).json({ error: "Unsupported file type. Please upload a PDF or text file." });
        }
      } else if (req.body?.text) {
        rawText = req.body.text;
        extracted = await analyzeBillWithAI(rawText);
      } else {
        return res.status(400).json({ error: "Please provide bill text or upload a file" });
      }

      if (rawText.trim().length < 20 && !usedBemAI) {
        return res.status(400).json({ error: "The provided text is too short to analyze. Please paste a complete itemized bill." });
      }

      const result = performDownstreamAnalysis(extracted);

      await storage.createAnalysis({
        facilityName: result.facilityName,
        patientName: result.patientName,
        billType: result.billType,
        rawText: rawText.substring(0, 5000),
        totalBilled: String(result.totalBilled),
        fairValue: String(result.fairValue),
        potentialSavings: String(result.potentialSavings),
        savingsPercent: String(result.savingsPercent),
        lineItems: result.lineItems,
        billingErrors: result.billingErrors,
        negotiationScript: result.negotiationScript,
        appealLetter: result.appealLetter,
        summary: result.summary,
      });

      return res.json(result);
    } catch (error: any) {
      console.error("Analysis error:", error);
      return res.status(500).json({ error: error.message || "Analysis failed" });
    }
  });

  app.get("/api/analyses", async (_req, res) => {
    try {
      const analyses = await storage.getRecentAnalyses();
      return res.json(analyses);
    } catch (error: any) {
      console.error("Error fetching analyses:", error);
      return res.status(500).json({ error: "Failed to fetch analyses" });
    }
  });

  app.get("/api/analyses/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const analysis = await storage.getAnalysis(id);
      if (!analysis) return res.status(404).json({ error: "Analysis not found" });
      return res.json(analysis);
    } catch (error: any) {
      return res.status(500).json({ error: "Failed to fetch analysis" });
    }
  });

  return httpServer;
}
